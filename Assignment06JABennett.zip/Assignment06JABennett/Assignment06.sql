--*************************************************************************--
-- Title: Assignment06
-- Author: Jeff_Bennett
-- Desc: This file demonstrates how to use Views
-- Change Log: When,Who,What
-- 2017-01-01,Jeff_Bennett,Created File
--**************************************************************************--
Begin Try
	Use Master;
	If Exists(Select Name From SysDatabases Where Name = 'Assignment06DB_Jeff_Bennett')
	 Begin 
	  Alter Database [Assignment06DB_Jeff_Bennett] set Single_user With Rollback Immediate;
	  Drop Database Assignment06DB_Jeff_Bennett;
	 End
	Create Database Assignment06DB_Jeff_Bennett;
End Try
Begin Catch
	Print Error_Number();
End Catch
go
Use Assignment06DB_Jeff_Bennett;

-- Create Tables (Module 01)-- 
Create Table Categories
([CategoryID] [int] IDENTITY(1,1) NOT NULL 
,[CategoryName] [nvarchar](100) NOT NULL
);
go

Create Table Products
([ProductID] [int] IDENTITY(1,1) NOT NULL 
,[ProductName] [nvarchar](100) NOT NULL 
,[CategoryID] [int] NULL  
,[UnitPrice] [mOney] NOT NULL
);
go

Create Table Employees -- New Table
([EmployeeID] [int] IDENTITY(1,1) NOT NULL 
,[EmployeeFirstName] [nvarchar](100) NOT NULL
,[EmployeeLastName] [nvarchar](100) NOT NULL 
,[ManagerID] [int] NULL  
);
go

Create Table Inventories
([InventoryID] [int] IDENTITY(1,1) NOT NULL
,[InventoryDate] [Date] NOT NULL
,[EmployeeID] [int] NOT NULL -- New Column
,[ProductID] [int] NOT NULL
,[Count] [int] NOT NULL
);
go

-- Add Constraints (Module 02) -- 
Begin  -- Categories
	Alter Table Categories 
	 Add Constraint pkCategories 
	  Primary Key (CategoryId);

	Alter Table Categories 
	 Add Constraint ukCategories 
	  Unique (CategoryName);
End
go 

Begin -- Products
	Alter Table Products 
	 Add Constraint pkProducts 
	  Primary Key (ProductId);

	Alter Table Products 
	 Add Constraint ukProducts 
	  Unique (ProductName);

	Alter Table Products 
	 Add Constraint fkProductsToCategories 
	  Foreign Key (CategoryId) References Categories(CategoryId);

	Alter Table Products 
	 Add Constraint ckProductUnitPriceZeroOrHigher 
	  Check (UnitPrice >= 0);
End
go

Begin -- Employees
	Alter Table Employees
	 Add Constraint pkEmployees 
	  Primary Key (EmployeeId);

	Alter Table Employees 
	 Add Constraint fkEmployeesToEmployeesManager 
	  Foreign Key (ManagerId) References Employees(EmployeeId);
End
go

Begin -- Inventories
	Alter Table Inventories 
	 Add Constraint pkInventories 
	  Primary Key (InventoryId);

	Alter Table Inventories
	 Add Constraint dfInventoryDate
	  Default GetDate() For InventoryDate;

	Alter Table Inventories
	 Add Constraint fkInventoriesToProducts
	  Foreign Key (ProductId) References Products(ProductId);

	Alter Table Inventories 
	 Add Constraint ckInventoryCountZeroOrHigher 
	  Check ([Count] >= 0);

	Alter Table Inventories
	 Add Constraint fkInventoriesToEmployees
	  Foreign Key (EmployeeId) References Employees(EmployeeId);
End 
go

-- Adding Data (Module 04) -- 
Insert Into Categories 
(CategoryName)
Select CategoryName 
 From Northwind.dbo.Categories
 Order By CategoryID;
go

Insert Into Products
(ProductName, CategoryID, UnitPrice)
Select ProductName,CategoryID, UnitPrice 
 From Northwind.dbo.Products
  Order By ProductID;
go

Insert Into Employees
(EmployeeFirstName, EmployeeLastName, ManagerID)
Select E.FirstName, E.LastName, IsNull(E.ReportsTo, E.EmployeeID) 
 From Northwind.dbo.Employees as E
  Order By E.EmployeeID;
go

Insert Into Inventories
(InventoryDate, EmployeeID, ProductID, [Count])
Select '20170101' as InventoryDate, 5 as EmployeeID, ProductID, ABS(CHECKSUM(NewId())) % 100 as RandomValue
From Northwind.dbo.Products
Union
Select '20170201' as InventoryDate, 7 as EmployeeID, ProductID, ABS(CHECKSUM(NewId())) % 100 as RandomValue
From Northwind.dbo.Products
Union
Select '20170301' as InventoryDate, 9 as EmployeeID, ProductID, ABS(CHECKSUM(NewId())) % 100 as RandomValue
From Northwind.dbo.Products
Order By 1, 2
go

-- Show the Current data in the Categories, Products, and Inventories Tables
Select * From Categories;
go
Select * From Products;
go
Select * From Employees;
go
Select * From Inventories;
go


/********************************* Questions and Answers *********************************/
'NOTES------------------------------------------------------------------------------------ 
 1) You can use any name you like for you views, but be descriptive and consistent
 2) You can use your working code from assignment 5 for much of this assignment
 3) You must use the BASIC views for each table after they are created in Question 1
------------------------------------------------------------------------------------------'

-- Question 1 (5 pts): How can you create BACIC views to show data from each table in the database.
-- NOTES: 1) Do not use a *, list out each column!
--        2) Create one view per table!
--		  3) Use SchemaBinding to protect the views from being orphaned!

Go
CREATE VIEW vCategories
WITH SCHEMABINDING
AS
SELECT 
   CategoryID, 
   CategoryName
FROM dbo.Categories;
Go

Go
CREATE VIEW vProducts
WITH SCHEMABINDING
AS
SELECT 
   ProductID, 
   ProductName, 
   CategoryID, 
   UnitPrice
FROM dbo.Products;
Go

Go
CREATE VIEW vEmployees
WITH SCHEMABINDING
AS
SELECT 
   EmployeeID, 
   EmployeeFirstName, 
   EmployeeLastName, 
   ManagerID
FROM dbo.Employees;
Go

Go
CREATE VIEW vInventories
WITH SCHEMABINDING
AS
SELECT 
   InventoryID, 
   InventoryDate, 
   EmployeeID, 
   ProductID, 
   [Count]
FROM dbo.Inventories;
Go

SELECT * FROM dbo.vCategories;
Go
SELECT * FROM dbo.vProducts;
Go
SELECT * FROM dbo.vEmployees;
Go
SELECT * FROM dbo.vInventories;
Go

-- Question 2 (5 pts): How can you set permissions, so that the public group CANNOT select data 
-- from each table, but can select data from each view?

DENY SELECT ON Categories TO PUBLIC;
GRANT SELECT ON vCategories TO PUBLIC;
Go

DENY SELECT ON Products TO PUBLIC;
GRANT SELECT ON vProducts TO PUBLIC;
Go

DENY SELECT ON Employees TO PUBLIC;
GRANT SELECT ON vEmployees TO PUBLIC;
Go

DENY SELECT ON Inventories TO PUBLIC;
GRANT SELECT ON vInventories TO PUBLIC;
Go

-- Question 3 (10 pts): How can you create a view to show a list of Category and Product names, 
-- and the price of each product?
-- Order the result by the Category and Product!

-- Here is an example of some rows selected from the view:
-- CategoryName,ProductName,UnitPrice
-- Beverages,Chai,18.00
-- Beverages,Chang,19.00
-- Beverages,Chartreuse verte,18.00

Go
CREATE VIEW vProductsByCategories
AS
SELECT TOP 10000000 
   C.CategoryName,
   P.ProductName,
   P.UnitPrice
FROM dbo.vCategories AS C
   INNER JOIN dbo.vProducts AS P
   ON C.CategoryID = P.CategoryID
ORDER BY 1, 2;
Go

-- Question 4 (10 pts): How can you create a view to show a list of Product names 
-- and Inventory Counts on each Inventory Date?
-- Order the results by the Product, Date, and Count!

-- Here is an example of some rows selected from the view:
--ProductName,InventoryDate,Count
--Alice Mutton,2017-01-01,15
--Alice Mutton,2017-02-01,78
--Alice Mutton,2017-03-01,83

Go
CREATE VIEW vInventoriesByProductsByDates
AS
SELECT TOP 10000000 
   P.ProductName, 
   I.InventoryDate, 
   [Count]
FROM dbo.vProducts AS P
   INNER JOIN dbo.vInventories AS I
   ON P.ProductID = I.ProductID
ORDER BY 1, 2, 3;
Go

-- Question 5 (10 pts): How can you create a view to show a list of Inventory Dates 
-- and the Employee that took the count?
-- Order the results by the Date and return only one row per date!

-- Here is an example of some rows selected from the view:
-- InventoryDate,EmployeeName
-- 2017-01-01,Steven Buchanan
-- 2017-02-01,Robert King
-- 2017-03-01,Anne Dodsworth

Go
CREATE VIEW vInventoriesByEmployeesByDates
AS
SELECT DISTINCT 
   I.InventoryDate, 
   [EmployeeName] = E.EmployeeFirstName + ' ' + E.EmployeeLastName
FROM dbo.vInventories AS I
   INNER JOIN dbo.vEmployees AS E
   ON I.EmployeeID = E.EmployeeID
Go


-- Question 6 (10 pts): How can you create a view show a list of Categories, Products, 
-- and the Inventory Date and Count of each product?
-- Order the results by the Category, Product, Date, and Count!

-- Here is an example of some rows selected from the view:
-- CategoryName,ProductName,InventoryDate,Count
-- Beverages,Chai,2017-01-01,72
-- Beverages,Chai,2017-02-01,52
-- Beverages,Chai,2017-03-01,54

Go
CREATE VIEW vInventoriesByProductsByCategories
AS
SELECT TOP 10000000
   C.CategoryName, 
   P.ProductName, 
   I.InventoryDate, 
   I.[Count]
FROM dbo.vCategories AS C
   INNER JOIN dbo.vProducts AS P
   ON C.CategoryID = P.CategoryID
   INNER JOIN dbo.vInventories AS I
   ON P.ProductID = I.ProductID
ORDER BY 1, 2, 3, 4;
Go

-- Question 7 (10 pts): How can you create a view to show a list of Categories, Products, 
-- the Inventory Date and Count of each product, and the EMPLOYEE who took the count?
-- Order the results by the Inventory Date, Category, Product and Employee!

-- Here is an example of some rows selected from the view:
-- CategoryName,ProductName,InventoryDate,Count,EmployeeName
-- Beverages,Chai,2017-01-01,72,Steven Buchanan
-- Beverages,Chang,2017-01-01,46,Steven Buchanan
-- Beverages,Chartreuse verte,2017-01-01,61,Steven Buchanan

Go
CREATE VIEW vInventoriesByProductsByEmployees
AS
SELECT TOP 10000000
   C.CategoryName, 
   P.ProductName, 
   I.InventoryDate, 
   I.[Count], 
   [EmployeeName] = E.EmployeeFirstName + ' ' + E.EmployeeLastName
FROM vCategories AS C
   INNER JOIN vProducts AS P
   ON C.CategoryID = P.CategoryID
   INNER JOIN vInventories AS I
   ON P.ProductID = I.ProductID
   INNER JOIN vEmployees AS E
   ON I.EmployeeID = E.EmployeeID
ORDER BY 3, 1, 2, 4;
Go

-- Question 8 (10 pts): How can you create a view to show a list of Categories, Products, 
-- the Inventory Date and Count of each product, and the Employee who took the count
-- for the Products 'Chai' and 'Chang'? 

-- Here is an example of some rows selected from the view:
-- CategoryName,ProductName,InventoryDate,Count,EmployeeName
-- Beverages,Chai,2017-01-01,72,Steven Buchanan
-- Beverages,Chang,2017-01-01,46,Steven Buchanan
-- Beverages,Chai,2017-02-01,52,Robert King

Go
CREATE VIEW vInventoriesForChaiAndChangByEmployees
AS
SELECT TOP 10000000
   C.CategoryName, 
   P.ProductName, 
   I.InventoryDate, 
   I.[Count], 
   [EmployeeName] = E.EmployeeFirstName + ' ' + E.EmployeeLastName
FROM vCategories AS C
   INNER JOIN vProducts AS P
   ON C.CategoryID = P.CategoryID
   INNER JOIN vInventories AS I
   ON I.ProductID = P.ProductID 
   INNER JOIN vEmployees AS E
   ON I.EmployeeID = E.EmployeeID
WHERE P.ProductID IN (SELECT ProductID
   FROM Products 
   WHERE ProductName IN ('Chai', 'Chang'))
ORDER BY 3, 1, 2, 4;
Go

-- Question 9 (10 pts): How can you create a view to show a list of Employees and the Manager who manages them?
-- Order the results by the Manager's name!

-- Here is an example of some rows selected from the view:
-- Manager,Employee
-- Andrew Fuller,Andrew Fuller
-- Andrew Fuller,Janet Leverling
-- Andrew Fuller,Laura Callahan

Go
CREATE VIEW vEmployeesByManager
AS
SELECT TOP 10000000
   [Manager] = M.EmployeeFirstName + ' ' + M.EmployeeLastName,
   [Employee] = E.EmployeeFirstName + ' ' + E.EmployeeLastName
FROM vEmployees AS E 
   INNER JOIN vEmployees AS M
   ON E.ManagerID = M.EmployeeID
ORDER BY 1, 2;
Go

-- Question 10 (10 pts): How can you create one view to show all the data from all four 
-- BASIC Views?

-- Here is an example of some rows selected from the view:
-- CategoryID,CategoryName,ProductID,ProductName,UnitPrice,InventoryID,InventoryDate,Count,EmployeeID,Employee,Manager
-- 1,Beverages,1,Chai,18.00,1,2017-01-01,72,5,Steven Buchanan,Andrew Fuller
-- 1,Beverages,1,Chai,18.00,78,2017-02-01,52,7,Robert King,Steven Buchanan
-- 1,Beverages,1,Chai,18.00,155,2017-03-01,54,9,Anne Dodsworth,Steven Buchanan

--====================================================================================
--PLEASE NOTE:  This table shows ALL data from the four tables as required; however only 3 of 9 
--employees take inventory, and so the data for those employees matches the example above.
--Data for the other 6 employees is also presented, but they have null values in non-employee related columns.
--=====================================================================================

Go
CREATE VIEW vInventoriesByProductsByCategoriesByEmployees
AS
SELECT TOP 10000000
   C.CategoryID,
   C.CategoryName,
   P.ProductID,
   P.ProductName,
   P.UnitPrice,
   I.InventoryID,
   I.InventoryDate,
   I.[Count],
   E.EmployeeID,
   [Employee] = E.EmployeeFirstName + ' ' + E.EmployeeLastName,
   [Manager] = M.EmployeeFirstName + ' ' + M.EmployeeLastName
FROM vCategories AS C
   INNER JOIN vProducts AS P
   ON C.CategoryID = P.CategoryID
   INNER JOIN vInventories AS I
   ON I.ProductID = P.ProductID 
   FULL JOIN vEmployees AS E
   ON I.EmployeeID = E.EmployeeID
   INNER JOIN vEmployees AS M
   ON M.EmployeeID = E.ManagerID
ORDER BY 1, 2, 3, 4, 5, 6, 7;
Go


Go

-- Test your Views (NOTE: You must change the names to match yours as needed!)
Select * From [dbo].[vCategories]
Select * From [dbo].[vProducts]
Select * From [dbo].[vInventories]
Select * From [dbo].[vEmployees]

Select * From [dbo].[vProductsByCategories]
Select * From [dbo].[vInventoriesByProductsByDates]
Select * From [dbo].[vInventoriesByEmployeesByDates]
Select * From [dbo].[vInventoriesByProductsByCategories]
Select * From [dbo].[vInventoriesByProductsByEmployees]
Select * From [dbo].[vInventoriesForChaiAndChangByEmployees]
Select * From [dbo].[vEmployeesByManager]
Select * From [dbo].[vInventoriesByProductsByCategoriesByEmployees]
/***************************************************************************************/